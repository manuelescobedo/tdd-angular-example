export const environment = {
  production: true,
  config: {
    apiUrl: "http://localhost:3000"
  }
};
